package exception;

public class LexerException extends CompilerException{
    public LexerException(){
        super();
    }
}
