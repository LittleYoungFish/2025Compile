package exception;

public class ParserException extends CompilerException{

    public ParserException() {
        super();
    }
}
