package backend.optimize;

import backend.ir.*;
import backend.ir.Module;
import backend.ir.inst.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LVNPass {
    private Module module;
    private Map<Integer, Instruction> hashTable = new HashMap<Integer, Instruction>();

    public LVNPass(Module module) {
        this.module = module;
    }

    public Module pass(){
        for (Function function : module.getFunctions()) {
            passFunc(function);
        }
        return module;
    }

    private void passFunc(Function function) {
        for (BasicBlock block : function.getBasicBlocks()) {
            passBlock(block);
        }
    }

    private void passBlock(BasicBlock block) {
        hashTable.clear();
        HashBuilder hashBuilder = new HashBuilder();

        List<Instruction> instructions = block.getInstructions();
        for (int i = 0; i < instructions.size(); i++) {
            Instruction instruction = instructions.get(i);

            if (instruction instanceof BrInst || instruction instanceof ReturnInst) {
                continue;
            }

            if (instruction instanceof StoreInst storeInst){
                Value ptr = storeInst.getPtr();
                while (ptr instanceof GetElementPtrInst getElementPtrInst){
                    ptr = getElementPtrInst.getElementBase();
                }
                hashBuilder.removeHash(storeInst.getPtr());
                continue;
            }

            int hash = hashBuilder.hash(instruction);
            if (hashTable.containsKey(hash)){
                instruction.replaceAllUseWith(hashTable.get(hash), false);
                i--;
            }else {
                hashTable.put(hash, instruction);
            }
        }
    }
}

class HashBuilder{
    private Map<String, Integer> descToHash = new HashMap<>();
    private Map<Value, Integer> valueToHash = new HashMap<>();
    private int nextHashValue = 0;

    public void reset(){
        descToHash.clear();
        valueToHash.clear();
        nextHashValue = 0;
    }

    public String createValueDesc(Value value){
        if (value instanceof GlobalValue globalValue){
            return "g " + globalValue.getName();
        }

        if (value instanceof ImmediateValue immediateValue){
            return "imm " + immediateValue.getValue();
        }

        if (value instanceof AllocInst){
            return "alloca" + value.hashCode();
        }

        if (value instanceof LoadInst loadInst){
            return "load "  + hash(loadInst.getPtr());
        }

        if (value instanceof CallInst){
            return "call" + value.hashCode();
        }

        List<String> hashList = ((User) value).getOperands().stream().map(this::hash).map(Object::toString).toList();
        String operandStr = String.join(", ", hashList);

        if (value instanceof BinaryInst binaryInst){
            return binaryInst.getOp().name() + " " + operandStr;
        }

        if (value instanceof GetElementPtrInst){
            return "gep " + operandStr;
        }

        if (value instanceof ICmpInst iCmpInst){
            return iCmpInst.getCond().name() + " " + operandStr;
        }

        if (value instanceof ZExtInst){
            return "zext " + operandStr;
        }

        return "";
    }

    public int hash(Value value){
        if (valueToHash.containsKey(value)){
            return valueToHash.get(value);
        }
        String desc = createValueDesc(value);
        if (descToHash.containsKey(desc)){
            int hash = descToHash.get(desc);
            valueToHash.put(value, hash);
            return hash;
        }

        int nextHash = nextHashValue++;
        valueToHash.put(value, nextHash);
        descToHash.put(desc, nextHash);

        return nextHash;
    }

    public void removeHash(Value value){
        String desc = createValueDesc(value);
        valueToHash.remove(value);
        descToHash.remove(desc);
    }
}
