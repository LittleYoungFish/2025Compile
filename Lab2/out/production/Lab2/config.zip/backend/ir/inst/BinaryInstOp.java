package backend.ir.inst;

public enum BinaryInstOp {
    ADD,
    SUB,
    MUL,
    SDIV,
    AND,
    OR,
    SREM,
}
